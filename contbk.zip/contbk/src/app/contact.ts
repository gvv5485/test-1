export class Contact{
    contactName: string;
    contactNumber: string;
    id: string;
}